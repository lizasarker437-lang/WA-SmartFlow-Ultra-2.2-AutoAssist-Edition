package com.smartflow.ultra;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.text.method.PasswordTransformationMethod;
import android.view.WindowManager;
import java.util.Arrays;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Build;
import android.provider.Settings;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.content.ComponentName;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Offline-first WebView shell for the bundled SmartFlow UI. No auto-sending. */
public class MainActivity extends Activity {
    private static final int PICK_FILE = 301;
    private static final int SAVE_FILE = 302;
    private static final int VOICE_INPUT = 303;
    private static final int PICK_PHONE_CONTACT = 305;
    private static final int NOTIFICATION_PERMISSION = 304;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private ValueCallback<Uri[]> pendingFileChooser;
    private String pendingFileContent;
    private boolean pageLoaded = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 14, 30));
        getWindow().setNavigationBarColor(Color.rgb(8, 14, 30));

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 14, 30));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // For Android's system file picker.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("appassets.androidplatform.net".equals(url.getHost())) {
                    WebResourceResponse response = loader.shouldInterceptRequest(url);
                    if (response != null) return response;
                }
                // Prevent accidental remote HTML/scripts loading inside the JS bridge WebView.
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                        java.util.Collections.emptyMap(),
                        new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) &&
                        "appassets.androidplatform.net".equals(uri.getHost()) &&
                        uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    return false;
                }
                // User-controlled external navigation is never loaded into this WebView.
                openExternal(uri);
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                webView.evaluateJavascript("window.__smartflowSyncAndroid && window.__smartflowSyncAndroid()", null);
                webView.evaluateJavascript("window.__smartflowRefreshReminderStatus && window.__smartflowRefreshReminderStatus()", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (Exception exc) {
                    pendingFileChooser = null;
                    toast("ফাইল বাছাই করা যাচ্ছে না");
                    return false;
                }
            }
        });
        setContentView(webView);
        ReminderScheduler.createNotificationChannel(this);
        webView.loadUrl(APP_URL);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private void openExternal(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(scheme) || host == null ||
                !(host.equalsIgnoreCase("wa.me") || host.equalsIgnoreCase("api.whatsapp.com"))) {
            toast("এই লিংক খোলা অনুমোদিত নয়");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            toast("WhatsApp বা ব্রাউজার পাওয়া যায়নি");
        }
    }

    private final class AppBridge {
        @JavascriptInterface public void openWhatsApp(String rawUrl) {
            runOnUiThread(() -> {
                try { openExternal(Uri.parse(rawUrl)); }
                catch (Exception ex) { toast("WhatsApp লিংক সঠিক নয়"); }
            });
        }
        @JavascriptInterface public void saveTextFile(String filename, String contents) {
            if (contents == null || contents.length() > 5_000_000) return;
            runOnUiThread(() -> {
                pendingFileContent = contents;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "WA-SmartFlow-backup.json");
                try { startActivityForResult(intent, SAVE_FILE); }
                catch (Exception ex) { toast("ব্যাকআপ সেভের জায়গা খোলা যায়নি"); }
            });
        }
        /** Stores only consented scheduled drafts; no WhatsApp message is sent silently. */
        @JavascriptInterface public void syncSchedules(String json) {
            if (json == null || json.length() > 700_000) return;
            runOnUiThread(() -> ReminderScheduler.replaceSchedules(MainActivity.this, json));
        }

        @JavascriptInterface public String reminderStatus() {
            boolean notifications = Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            boolean exact = Build.VERSION.SDK_INT < 31 || (am != null && am.canScheduleExactAlarms());
            JSONObject data = new JSONObject();
            try {
                data.put("notifications", notifications);
                data.put("exact", exact);
                data.put("android", Build.VERSION.SDK_INT);
                data.put("mode", "opt_in_accessibility_assist");
                data.put("autoEnabled",AutoAssistState.isEnabled(MainActivity.this));
                data.put("accessibility",AutoAssistState.accessibilityEnabled(MainActivity.this));
                data.put("service",WhatsAppAssistService.active());
                data.put("lastAttemptAt",AutoAssistState.getLong(MainActivity.this,"last_attempt_at"));
                data.put("pinSaved",PinVault.hasPin(MainActivity.this));
                data.put("pinEnabled",PinVault.enabled(MainActivity.this));
            } catch (Exception ignored) {}
            return data.toString();
        }

        /** UI send assistance; the separate local encrypted PIN feature is opt-in. */
        @JavascriptInterface public void enableAutoAssist(boolean enabled) {
            AutoAssistState.setEnabled(MainActivity.this,enabled);
            runOnUiThread(() -> {
                if(enabled)toast("অটো-সেন্ড পরীক্ষামূলক। Accessibility অনুমতি দিন এবং কন্টাক্টের নাম যাচাই করুন।");
                updateReminderStatus();
            });
        }
        /** Native password-only dialog: never gives the PIN to the WebView or to remote services. */
        @JavascriptInterface public void configureAutoPin() {
            runOnUiThread(() -> {
                final EditText field=new EditText(MainActivity.this);
                field.setSingleLine(true);
                field.setHint("৪–৮ অঙ্কের ফোন PIN");
                field.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                field.setTransformationMethod(PasswordTransformationMethod.getInstance());
                LinearLayout container=new LinearLayout(MainActivity.this);
                container.setPadding(48,20,48,8);
                container.addView(field);
                AlertDialog dialog=new AlertDialog.Builder(MainActivity.this)
                    .setTitle("🔐 পরীক্ষামূলক Auto PIN Unlock")
                    .setMessage("এটি শুধুমাত্র নিজের ফোনে ব্যবহার করুন। Android/HyperOS-এ কাজ নাও করতে পারে। একবার ব্যর্থ হলে পুনরায় PIN চেষ্টা করবে না। PIN শুধু এই ফোনে এনক্রিপ্টেড থাকবে; PIN বদলালে এখানে মুছে দিন।")
                    .setView(container)
                    .setNegativeButton("বাতিল",(d,w)->{})
                    .setPositiveButton("সংরক্ষণ",null).create();
                dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    char[] secret=field.getText().toString().toCharArray();
                    field.getText().clear();
                    try {
                        PinVault.save(MainActivity.this,secret);
                        toast("PIN এনক্রিপ্ট করে ফোনে রাখা হয়েছে; এটি নিশ্চিত আনলক নয়।");
                        dialog.dismiss();
                        updateReminderStatus();
                    }catch(Exception ex){toast("PIN সংরক্ষণ ব্যর্থ: ৪–৮টি সংখ্যা দিন");}
                    finally{Arrays.fill(secret,'\0');}
                }));
                dialog.show();
                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            });
        }
        @JavascriptInterface public void removeAutoPin() {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("PIN মুছবেন?")
                .setMessage("সংরক্ষিত PIN ও স্বয়ংক্রিয় আনলক অনুমতি মুছে যাবে।")
                .setNegativeButton("বাতিল",(d,w)->{})
                .setPositiveButton("মুছুন",(d,w)->{PinVault.clear(MainActivity.this);updateReminderStatus();toast("সংরক্ষিত PIN মুছে গেছে");})
                .show());
        }
        @JavascriptInterface public void disableAutoPin() {
            PinVault.setEnabled(MainActivity.this,false);
            runOnUiThread(() -> {updateReminderStatus();toast("Auto PIN Unlock বন্ধ");});
        }
        @JavascriptInterface public void enableSavedAutoPin() {
            if(PinVault.hasPin(MainActivity.this))PinVault.setEnabled(MainActivity.this,true);
            runOnUiThread(() -> {updateReminderStatus();toast(PinVault.hasPin(MainActivity.this)?"পরীক্ষামূলক Auto PIN চালু":"আগে PIN সেভ করুন");});
        }
        @JavascriptInterface public void openAccessibilitySettings() {
            runOnUiThread(() -> {
                try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
                catch(Exception ignored){toast("Accessibility Settings খোলা যাচ্ছে না");}
            });
        }
        @JavascriptInterface public void enableReminders() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
                } else openExactAlarmPermissionIfNeeded();
            });
        }
        /** The user chooses one phone-number row. No bulk contacts read. */
        @JavascriptInterface public void pickPhoneContact() {
            runOnUiThread(() -> {
                try {
                    Intent pick = new Intent(Intent.ACTION_PICK);
                    pick.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
                    startActivityForResult(pick, PICK_PHONE_CONTACT);
                } catch (Exception ex) {
                    toast("ফোনের Contacts তালিকা খোলা যাচ্ছে না");
                }
            });
        }
        @JavascriptInterface public void voiceInput() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় মেসেজ বলুন");
                    startActivityForResult(intent, VOICE_INPUT);
                } catch (Exception exc) {
                    toast("এই ফোনে ভয়েস টাইপিং সার্ভিস পাওয়া যায়নি");
                }
            });
        }
    }

    private void openExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception ignored) {
                    toast("Settings → Apps → Special app access → Alarms & reminders চালু করুন");
                }
            }
        }
        updateReminderStatus();
    }

    private void updateReminderStatus() {
        if (webView != null && pageLoaded)
            webView.evaluateJavascript("window.__smartflowRefreshReminderStatus && window.__smartflowRefreshReminderStatus()", null);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION) openExactAlarmPermissionIfNeeded();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (pendingFileChooser != null) {
                Uri[] uris = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                pendingFileChooser.onReceiveValue(uris);
                pendingFileChooser = null;
            }
        } else if (requestCode == SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null &&
                    pendingFileContent != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Cannot open file");
                    out.write(pendingFileContent.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    toast("✅ ব্যাকআপ সংরক্ষণ হয়েছে");
                } catch (Exception exc) { toast("ব্যাকআপ সেভ করা যায়নি"); }
            }
            pendingFileContent = null;
        } else if (requestCode == PICK_PHONE_CONTACT && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri selected = data.getData();
            // Android grants access to the selected phone row only.
            String name = "";
            String number = "";
            String[] columns = {
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            try (Cursor cursor = getContentResolver().query(selected, columns, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                    int numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    if (nameIndex >= 0) name = cursor.getString(nameIndex);
                    if (numberIndex >= 0) number = cursor.getString(numberIndex);
                }
            } catch (Exception ex) {
                toast("নির্বাচিত নম্বর পড়া যায়নি");
            }
            if (number != null && !number.trim().isEmpty()) {
                String payload = JSONObject.quote(name == null ? "" : name) + "," +
                        JSONObject.quote(number);
                webView.evaluateJavascript(
                        "window.__smartflowReceiveContact && window.__smartflowReceiveContact(" +
                        payload + ")", null);
            } else toast("কন্টাক্টটিতে ফোন নম্বর নেই");
        } else if (requestCode == VOICE_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> strings = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (strings != null && !strings.isEmpty()) {
                String js = "window.__smartflowSetVoice(" + JSONObject.quote(strings.get(0)) + ")";
                webView.evaluateJavascript(js, null);
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pageLoaded && webView != null) {
            webView.evaluateJavascript("window.__smartflowResumed && window.__smartflowResumed()", null);
            updateReminderStatus();
            ReminderScheduler.restoreSchedules(this);
        }
    }

    @Override public void onBackPressed() {
        if (webView == null || !pageLoaded) { super.onBackPressed(); return; }
        webView.evaluateJavascript("String(window.__smartflowOnBack && window.__smartflowOnBack())", value -> {
            if (!"\"true\"".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (pendingFileChooser != null) {
            pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }
}
