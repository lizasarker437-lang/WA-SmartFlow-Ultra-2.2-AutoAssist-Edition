package com.smartflow.ultra;

import android.Manifest;
import android.app.Notification;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.net.Uri;
import org.json.JSONObject;

/** Reminder plus optional foreground AccessibilityService auto-assist. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra(ReminderScheduler.EXTRA_ID);
        String phase = intent.getStringExtra(ReminderScheduler.EXTRA_PHASE);
        if (id == null || !("preview".equals(phase) || "due".equals(phase))) return;
        JSONObject item = ReminderScheduler.findById(ctx,id);
        if (item == null || !item.optBoolean("consent",false)) return;
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        ReminderScheduler.createNotificationChannel(ctx);
        boolean preview = "preview".equals(phase);
        String title = preview ? "⏳ ৩ সেকেন্ড পরে মেসেজের সময়" : "💬 WhatsApp মেসেজের সময় হয়েছে";
        boolean auto = AutoAssistState.isEnabled(ctx) && WhatsAppAssistService.active();
        if(preview && auto) WhatsAppAssistService.previewSoon();
        if(!preview && auto) {
            // Queue only schedules whose recipients were expressly marked as consenting.
            boolean queued = AutoAssistState.queue(ctx,item,AutoAssistState.locked(ctx));
            if(queued) WhatsAppAssistService.tryPending();
        }
        String body = preview ? "প্রায় ৩ সেকেন্ড পরে নির্ধারিত মেসেজের সময়।" :
                (auto ? "স্বয়ংক্রিয় পাঠানোর চেষ্টা চলছে; প্রয়োজনে এখানে চাপুন। PIN লক থাকলে আগে আনলক করুন।" :
                        "WhatsApp খুলে মেসেজ দেখে Send চাপুন।");

        // User-tapped action may launch from the background and ask the OS to unlock.
        Intent open=new Intent(ctx, preview ? MainActivity.class : ScheduleLaunchActivity.class);
        open.setData(Uri.parse("smartflow://launch/" + Uri.encode(id) + "/" + phase));
        open.putExtra(ReminderScheduler.EXTRA_ID,id);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent tap=PendingIntent.getActivity(ctx,0,open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(ctx,ReminderScheduler.CHANNEL) : new Notification.Builder(ctx);
        builder.setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setContentIntent(tap)
                .setPriority(Notification.PRIORITY_HIGH)
                .addAction(new Notification.Action.Builder(null,
                        preview ? "শিডিউল দেখুন" : "WhatsApp খুলুন", tap).build());
        if (Build.VERSION.SDK_INT < 26) builder.setDefaults(Notification.DEFAULT_ALL);

        // On a locked screen, don't reveal recipient, message body or WhatsApp contact number.
        Notification.Builder publicNotice = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(ctx, ReminderScheduler.CHANNEL) : new Notification.Builder(ctx);
        publicNotice.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("SmartFlow Reminder")
                .setContentText("একটি নির্ধারিত মেসেজের রিমাইন্ডার")
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        builder.setPublicVersion(publicNotice.build());
        NotificationManager manager=(NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((id + phase).hashCode(),builder.build());
    }
}
