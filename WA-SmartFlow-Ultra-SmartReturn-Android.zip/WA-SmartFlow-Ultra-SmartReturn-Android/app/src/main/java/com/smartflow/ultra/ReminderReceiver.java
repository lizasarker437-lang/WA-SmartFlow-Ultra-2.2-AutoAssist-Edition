package com.smartflow.ultra;

import android.Manifest;
import android.app.Notification;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.net.Uri;
import org.json.JSONObject;

/** Reminder plus optional foreground AccessibilityService auto-assist. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra(ReminderScheduler.EXTRA_ID);
        String phase = intent.getStringExtra(ReminderScheduler.EXTRA_PHASE);
        if (id == null || !("preview".equals(phase) || "due".equals(phase))) return;
        JSONObject item = ReminderScheduler.findById(ctx,id);
        if (item == null || !item.optBoolean("consent",false)) return;
        boolean canNotify = Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        ReminderScheduler.createNotificationChannel(ctx);
        boolean preview = "preview".equals(phase);
        boolean auto = AutoAssistState.isEnabled(ctx) && WhatsAppAssistService.active();
        if (preview) {
            // No notification: the screen-on Accessibility overlay is the only countdown UI.
            if(auto) WhatsAppAssistService.previewSoon(id,ReminderScheduler.dueMillis(item));
            return;
        }
        if (auto) {
            boolean queued = AutoAssistState.queue(ctx,item,AutoAssistState.locked(ctx),
                    WhatsAppAssistService.previousAppPackage());
            if (queued) {
                WhatsAppAssistService.tryPending();
                return; // No status-bar notifications for a normally running automation.
            }
        }
        // The single actionable reminder below is a fallback only (auto service absent/failed).
        String title = "💬 WhatsApp মেসেজের সময় হয়েছে";
        String body = "WhatsApp খুলে মেসেজ দেখে Send চাপুন।";

        // User-tapped action may launch from the background and ask the OS to unlock.
        Intent open=new Intent(ctx, ScheduleLaunchActivity.class);
        open.setData(Uri.parse("smartflow://launch/" + Uri.encode(id) + "/" + phase));
        open.putExtra(ReminderScheduler.EXTRA_ID,id);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent tap=PendingIntent.getActivity(ctx,0,open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(ctx,ReminderScheduler.CHANNEL) : new Notification.Builder(ctx);
        builder.setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setContentIntent(tap)
                .setPriority(Notification.PRIORITY_HIGH)
                .addAction(new Notification.Action.Builder(null,
                        "WhatsApp খুলুন", tap).build());
        if (Build.VERSION.SDK_INT < 26) builder.setDefaults(Notification.DEFAULT_ALL);

        // On a locked screen, don't reveal recipient, message body or WhatsApp contact number.
        Notification.Builder publicNotice = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(ctx, ReminderScheduler.CHANNEL) : new Notification.Builder(ctx);
        publicNotice.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("SmartFlow Reminder")
                .setContentText("একটি নির্ধারিত মেসেজের রিমাইন্ডার")
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        builder.setPublicVersion(publicNotice.build());
        NotificationManager manager=(NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (canNotify && manager != null) manager.notify((id + phase).hashCode(),builder.build());
    }
}
