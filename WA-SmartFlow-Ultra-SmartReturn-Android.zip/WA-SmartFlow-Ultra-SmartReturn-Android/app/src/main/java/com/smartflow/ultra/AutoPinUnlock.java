package com.smartflow.ultra;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.PowerManager;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Arrays;
import java.util.Locale;

/** Experimental PIN-keypad interaction on the owner's Xiaomi system lock screen.
 *  Never uses root/ADB, modifies Android credentials, or disables the system lock.
 *  One attempt per scheduled task; fail closed if no accessibility keypad is visible.
 *  No hard-coded coordinate guessing: requires accessible system keypad digit nodes.
 */
final class AutoPinUnlock {
    private static final long MAX_UNLOCK_WINDOW_MS=10500;
    private final WhatsAppAssistService service;
    private final Handler handler;
    private boolean running=false;
    private String activeTask="";
    private char[] pin;
    private int position;
    private long started;
    AutoPinUnlock(WhatsAppAssistService svc,Handler h) {service=svc;handler=h;}
    boolean isRunning(){return running;}
    void stop() {
        running=false;
        if(pin!=null){Arrays.fill(pin,'\0');pin=null;}
        activeTask="";
    }
    void startIfNeeded(){
        if(running||!PinVault.enabled(service)||!AutoAssistState.valid(service))return;
        if(!"queued".equals(AutoAssistState.get(service,"phase")))return;
        if(!AutoAssistState.locked(service))return;
        String id=AutoAssistState.get(service,"id");
        if(id.isEmpty())return;
        // No repeated guess on the same message, even after a service restart.
        String trialKey=id+":"+AutoAssistState.getLong(service,"timestamp");
        if(trialKey.equals(AutoAssistState.get(service,"pin_trial_id")))return;
        pin=PinVault.read(service);
        if(pin==null||pin.length<4||pin.length>8){stop();return;}
        service.getSharedPreferences("smartflow_autoassist_v1",Context.MODE_PRIVATE).edit()
            .putString("pin_trial_id",trialKey).commit();
        running=true;activeTask=id;position=0;started=System.currentTimeMillis();
        wakeUp();
        handler.postDelayed(this::enterNext,550);
    }
    private void wakeUp(){
        try {
            PowerManager pm=(PowerManager)service.getSystemService(Context.POWER_SERVICE);
            if(pm!=null&&!pm.isInteractive()){
                // Legacy wake flags are OEM dependent; they do not disable the keyguard.
                PowerManager.WakeLock wl=pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK |
                   PowerManager.ACQUIRE_CAUSES_WAKEUP,"SmartFlow:ScheduledUnlock");
                wl.acquire(4000);
            }
        }catch(Exception ignored){}
    }
    private void enterNext(){
        if(!running)return;
        if(System.currentTimeMillis()-started>MAX_UNLOCK_WINDOW_MS){stop();return;}
        if(!activeTask.equals(AutoAssistState.get(service,"id"))){stop();return;}
        if(!AutoAssistState.locked(service)){
            stop();service.tryReadyAfterUnlock();return;
        }
        AccessibilityNodeInfo root=service.getRootInActiveWindow();
        if(root==null||root.getPackageName()==null||!isSystemKeyguard(root.getPackageName().toString())){
            // First screens sometimes show a swipe-to-unlock affordance, not a keypad.
            if(position==0)trySwipeUp();
            handler.postDelayed(this::enterNext,650);
            return;
        }
        if(position>=pin.length){
            // Do not retry or guess after an incorrect PIN or an OEM error.
            handler.postDelayed(()->{
                if(!AutoAssistState.locked(service))service.tryReadyAfterUnlock();
                stop();
            },1100);
            return;
        }
        AccessibilityNodeInfo key=findDigit(root,pin[position],0);
        if(key==null){
            if(position==0)trySwipeUp();
            handler.postDelayed(this::enterNext,550);
            return;
        }
        AccessibilityNodeInfo clickTarget=key;
        for(int tries=0;tries<3&&!clickTarget.isClickable()&&clickTarget.getParent()!=null;tries++){
            clickTarget=clickTarget.getParent();
        }
        if(!clickTarget.isClickable()||!clickTarget.isEnabled()||!clickTarget.isVisibleToUser()){
            handler.postDelayed(this::enterNext,400);return;
        }
        boolean ok=clickTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if(!ok){stop();return;}
        position++;
        handler.postDelayed(this::enterNext,260);
    }
    private static boolean isSystemKeyguard(String pkg){
        return "com.android.systemui".equals(pkg) || "com.miui.systemui".equals(pkg);
    }
    private static AccessibilityNodeInfo findDigit(AccessibilityNodeInfo n,char digit,int depth){
        if(n==null||depth>25)return null;
        String cls=n.getClassName()==null?"":n.getClassName().toString();
        String t=n.getText()==null?"":n.getText().toString().trim();
        String d=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
        String v=n.getViewIdResourceName()==null?"":n.getViewIdResourceName().toLowerCase(Locale.ROOT);
        String target=String.valueOf(digit);
        boolean digitMatch=t.equals(target)||d.equals(target)||
            d.equalsIgnoreCase("digit "+target)||d.equalsIgnoreCase("key "+target)||
            v.endsWith("key"+target)||v.endsWith("key_"+target)||v.endsWith("digit"+target);
        // Ignore password fields and non-numeric controls; only inspect system UI.
        if(digitMatch&&n.isVisibleToUser()&&!n.isPassword())return n;
        for(int i=0;i<Math.min(n.getChildCount(),70);i++){
            AccessibilityNodeInfo found=findDigit(n.getChild(i),digit,depth+1);
            if(found!=null)return found;
        }
        return null;
    }
    private void trySwipeUp(){
        if(Build.VERSION.SDK_INT<24)return;
        try {
            WindowManager wm=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
            if(wm==null)return;
            android.util.DisplayMetrics m=new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            Path p=new Path();p.moveTo(m.widthPixels*.5f,m.heightPixels*.8f);
            p.lineTo(m.widthPixels*.5f,m.heightPixels*.38f);
            GestureDescription.Builder b=new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p,0,380));
            service.dispatchGesture(b.build(),null,null);
        }catch(Exception ignored){}
    }
}
