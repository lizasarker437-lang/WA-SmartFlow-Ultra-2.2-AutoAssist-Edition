package com.smartflow.ultra;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-register reminders after boot, package update, time zone change or exact-alarm permission grant. */
public class ReminderRestoreReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        ReminderScheduler.restoreSchedules(context);
    }
}
