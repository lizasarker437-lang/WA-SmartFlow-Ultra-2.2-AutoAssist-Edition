package com.smartflow.ultra;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Exact-time reminder alarms; when opt-in assist is active, preview is overlay-only. */
final class ReminderScheduler {
    static final String CHANNEL = "smartflow_schedules_v1";
    static final String EXTRA_ID = "schedule_id";
    static final String EXTRA_PHASE = "phase";
    private static final String PREFS = "reminder_schedules_v1";
    private static final String ITEMS = "items";
    private static final int MAX_SCHEDULES = 300;
    private static final long THREE_SECONDS = 3000;

    private ReminderScheduler() {}

    static void createNotificationChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager mgr = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel(CHANNEL, "WhatsApp মেসেজ রিমাইন্ডার",
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("নির্ধারিত সময়ের আগে ও সময়ে WhatsApp-এ মেসেজ খোলার স্মরণবার্তা");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            mgr.createNotificationChannel(channel);
        }
    }

    static void replaceSchedules(Context ctx, String json) {
        try {
            JSONArray incoming = new JSONArray(json);
            JSONArray safe = new JSONArray();
            for (int i = 0; i < Math.min(incoming.length(), MAX_SCHEDULES); i++) {
                JSONObject x = incoming.optJSONObject(i);
                if (x == null || !"scheduled".equals(x.optString("status")) ||
                        !x.optBoolean("consent", false)) continue;
                String id = x.optString("id"), phone = cleanPhone(x.optString("phone")),
                        text = x.optString("text"), date = x.optString("date"), time = x.optString("time");
                if (id.isEmpty() || id.length() > 70 || !phone.matches("[0-9]{8,15}") ||
                        text.isEmpty() || text.length() > 4000 || parseLocal(date, time) <= 0) continue;
                safe.put(x);
            }
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String old = prefs.getString(ITEMS, "[]");
            cancelAll(ctx, new JSONArray(old));
            // Commit synchronously so alarms can find data even if the process is immediately killed.
            prefs.edit().putString(ITEMS, safe.toString()).commit();
            registerAll(ctx, safe);
        } catch (Exception ignored) {
            // Do not replace previously saved schedules with malformed input.
        }
    }

    static void restoreSchedules(Context ctx) {
        try {
            JSONArray items = getAll(ctx);
            registerAll(ctx, items);
        } catch (Exception ignored) { }
    }

    private static JSONArray getAll(Context ctx) throws Exception {
        return new JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ITEMS,"[]"));
    }

    static JSONObject findById(Context ctx, String id) {
        try {
            JSONArray all = getAll(ctx);
            for (int i=0; i<all.length(); i++) {
                JSONObject x = all.optJSONObject(i);
                if (x != null && id.equals(x.optString("id"))) return x;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static long parseLocal(String day, String time) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            f.setLenient(false);
            Date date = f.parse(day + " " + time);
            return date == null ? -1L : date.getTime();
        } catch (Exception ignored) { return -1L; }
    }

    static long dueMillis(JSONObject item) {
        return item==null ? -1L : parseLocal(item.optString("date"),item.optString("time"));
    }

    private static String cleanPhone(String phone) {
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.matches("01[0-9]{9}")) digits="88"+digits;
        if (digits.matches("1[0-9]{9}")) digits="880"+digits;
        return digits;
    }

    static String whatsappUrl(JSONObject item) {
        String text = item.optString("text", "");
        text = text.replace("{{নাম}}", item.optString("name", ""))
                .replace("{{তারিখ}}", item.optString("date", ""));
        return "https://wa.me/" + cleanPhone(item.optString("phone", "")) +
                "?text=" + Uri.encode(text);
    }

    private static PendingIntent alarmIntent(Context ctx, String id, String phase) {
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.setAction("com.smartflow.ultra.REMINDER_" + phase);
        intent.setData(Uri.parse("smartflow://remind/" + Uri.encode(id) + "/" + phase));
        intent.putExtra(EXTRA_ID,id);
        intent.putExtra(EXTRA_PHASE,phase);
        return PendingIntent.getBroadcast(ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void cancelAll(Context ctx, JSONArray all) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i=0; i<all.length(); i++) {
            JSONObject x = all.optJSONObject(i);
            if (x == null) continue;
            String id = x.optString("id");
            if (!id.isEmpty()) {
                am.cancel(alarmIntent(ctx,id,"preview"));
                am.cancel(alarmIntent(ctx,id,"due"));
            }
        }
    }

    private static void registerAll(Context ctx, JSONArray all) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        long now = System.currentTimeMillis();
        for (int i=0; i<all.length(); i++) {
            JSONObject item=all.optJSONObject(i);
            if (item == null) continue;
            long due=parseLocal(item.optString("date"),item.optString("time"));
            String id = item.optString("id");
            if (due <= now || id.isEmpty()) continue;
            // Preview is best-effort; Android may delay it (especially in Doze / Xiaomi battery saving).
            long pre=due-THREE_SECONDS;
            if (pre > now) scheduleAlarm(am, exact, pre, alarmIntent(ctx,id,"preview"), false);
            scheduleAlarm(am, exact, due, alarmIntent(ctx,id,"due"), true);
        }
    }

    private static void scheduleAlarm(AlarmManager am, boolean exact, long when, PendingIntent pi, boolean doze) {
        try {
            if (exact) {
                if (doze && Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
                else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP,when,pi);
            }
        } catch (SecurityException ignored) {
            // When exact alarm permission changes, still retain a best-effort alarm.
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.set(AlarmManager.RTC_WAKEUP,when,pi);
        }
    }
}
