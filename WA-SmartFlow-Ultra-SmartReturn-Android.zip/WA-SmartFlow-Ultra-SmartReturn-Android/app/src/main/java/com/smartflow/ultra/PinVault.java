package com.smartflow.ultra;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** PIN stays on the device, encrypted with Android Keystore AES-GCM.
 *  This is an experimental personal automation feature, NOT a system unlock API.
 *  Never syncs, logs, exports, or sends the credential. No app backup is allowed. */
final class PinVault {
    private static final String STORE="private_auto_pin_v1";
    private static final String ALIAS="com.smartflow.ultra.pin_keystore_v1";
    private static final String DATA="ciphertext";
    private static final String IV="iv";
    private static final String ENABLE="pin_opt_in";
    private PinVault() {}
    private static SharedPreferences prefs(Context c) {return c.getSharedPreferences(STORE,Context.MODE_PRIVATE);}
    static boolean enabled(Context c) {return prefs(c).getBoolean(ENABLE,false) && hasPin(c);}
    static boolean hasPin(Context c) {return prefs(c).contains(DATA) && prefs(c).contains(IV);}
    static void setEnabled(Context c,boolean enabled) {prefs(c).edit().putBoolean(ENABLE,enabled).apply();}

    private static SecretKey getOrCreate() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if(store.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        KeyGenParameterSpec spec=new KeyGenParameterSpec.Builder(ALIAS,
              KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
              .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
              .setRandomizedEncryptionRequired(true).build();
        generator.init(spec);
        return generator.generateKey();
    }
    static synchronized void save(Context c,char[] pin) throws Exception {
        if(pin==null||pin.length<4||pin.length>8)throw new IllegalArgumentException("PIN must contain 4-8 digits");
        for(char digit:pin)if(digit<'0'||digit>'9')throw new IllegalArgumentException("Only digits allowed");
        byte[] raw=new byte[pin.length];
        for(int i=0;i<pin.length;i++)raw[i]=(byte)pin[i];
        try{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE,getOrCreate());
            byte[] encrypted=cipher.doFinal(raw);
            if(!prefs(c).edit().putString(DATA,Base64.encodeToString(encrypted,Base64.NO_WRAP))
                .putString(IV,Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP))
                .putBoolean(ENABLE,true).commit())throw new Exception("Could not save PIN");
        }finally{java.util.Arrays.fill(raw,(byte)0);java.util.Arrays.fill(pin,'\0');}
    }
    static synchronized char[] read(Context c) {
        if(!enabled(c))return null;
        byte[] decrypted=null;
        try{
            byte[] iv=Base64.decode(prefs(c).getString(IV,""),Base64.NO_WRAP);
            byte[] encrypted=Base64.decode(prefs(c).getString(DATA,""),Base64.NO_WRAP);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,getOrCreate(),new GCMParameterSpec(128,iv));
            decrypted=cipher.doFinal(encrypted);
            char[] result=new char[decrypted.length];
            for(int i=0;i<result.length;i++)result[i]=(char)(decrypted[i]&255);
            return result;
        }catch(Exception ignored){return null;}
        finally{if(decrypted!=null)java.util.Arrays.fill(decrypted,(byte)0);}
    }
    static void clear(Context c) {
        prefs(c).edit().clear().commit();
        // Keep the keystore key to avoid surprising races with in-flight jobs.
    }
}
