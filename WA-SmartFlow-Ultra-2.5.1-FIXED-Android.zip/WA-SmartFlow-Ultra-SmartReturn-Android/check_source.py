#!/usr/bin/env python3
"""Preflight checks for the SmartReturn Java source. Not a substitute for javac."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent
java=p/'app/src/main/java/com/smartflow/ultra'
launch=(java/'ScheduleLaunchActivity.java').read_text(encoding='utf8')
state=(java/'AutoAssistState.java').read_text(encoding='utf8')
assert 'queue(Context c,JSONObject item,boolean wasLocked,String previousPackage)' in state, 'queue must accept four arguments'
assert 'AutoAssistState.queue(this,item,lockedAtDue,' in launch, 'Call must provide the previous app argument'
assert 'AutoAssistState.queue(this,item,lockedAtDue) &&' not in launch, 'Old 3-arg call still exists'
for f in (p/'app/src/main').rglob('*.xml'):
    ET.parse(f)
assert (p/'app/src/main/assets/index.html').exists(), 'Premium UI missing'
print('PASS: 4-argument queue call, app assets and XML resources verified.')
