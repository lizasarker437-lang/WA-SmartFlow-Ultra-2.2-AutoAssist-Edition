package com.smartflow.ultra;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import org.json.JSONObject;

/** Visible notification action: requests system authentication, never handles/stores a PIN. */
public class ScheduleLaunchActivity extends Activity {
    private String scheduleId;
    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        scheduleId=getIntent().getStringExtra(ReminderScheduler.EXTRA_ID);
        TextView text=new TextView(this);text.setGravity(Gravity.CENTER);text.setTextSize(19);
        text.setPadding(35,35,35,35);
        text.setText("🔒 ফোন লক থাকলে সিস্টেমের PIN/ফিঙ্গারপ্রিন্ট দিয়ে আনলক করুন। তারপর WhatsApp খুলবে।");
        setContentView(text);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        KeyguardManager keyguard=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if(Build.VERSION.SDK_INT>=26&&keyguard!=null&&keyguard.isDeviceLocked()){
            keyguard.requestDismissKeyguard(this,new KeyguardManager.KeyguardDismissCallback(){
                @Override public void onDismissSucceeded(){openScheduledChat();}
                @Override public void onDismissCancelled(){finish();}
                @Override public void onDismissError(){finish();}
            });
        }else openScheduledChat();
    }
    private void openScheduledChat(){
        JSONObject item=ReminderScheduler.findById(this,scheduleId);
        if(item==null||!item.optBoolean("consent",false)){finish();return;}
        boolean assistReady=false;
        if(AutoAssistState.isEnabled(this)&&WhatsAppAssistService.active()){
            // Preserve was_locked captured when alarm fired. Queue only if not already queued.
            boolean lockedAtDue=AutoAssistState.wasLocked(this);
            assistReady=AutoAssistState.queue(this,item,lockedAtDue) &&
                    scheduleId.equals(AutoAssistState.get(this,"id"));
        }
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(ReminderScheduler.whatsappUrl(item)));
            i.setPackage("com.whatsapp");
            startActivity(i);
            if(assistReady) WhatsAppAssistService.openedFromActivity(this);
        }catch(Exception ex){
            // No auto click outside the official WhatsApp package.
            android.widget.Toast.makeText(this,"WhatsApp খুলতে পারিনি। অ্যাপটি ইনস্টল আছে কি না দেখুন।",android.widget.Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
