# WA SmartFlow Ultra 2.2 — Smart AutoAssist (Xiaomi Android)

এটি অফলাইন-প্রধান Android অ্যাপ। Premium UI, বাংলা শিডিউল, কন্টাক্ট, টেমপ্লেট, ব্যাকআপ, Android AlarmManager রিমাইন্ডার ও ঐচ্ছিক AccessibilityService-ভিত্তিক WhatsApp AutoAssist রয়েছে।

## নিরাপত্তা ও নির্ভরযোগ্যতা
- **PIN/পাসওয়ার্ড/ফিঙ্গারপ্রিন্ট বাইপাস নেই।** নিরাপদ Keyguard হলে শুধু Android-এর নিজস্ব আনলক স্ক্রিন দেখানো যায়। PIN কখনো অ্যাপে চাওয়া বা সেভ করা হয় না।
- **Smart AutoAssist শুরুতে বন্ধ।** কন্ট্রোল সেন্টার থেকে আলাদাভাবে চালু এবং Accessibility Settings-এ ব্যবহারকারীর অনুমতি দিতে হবে। শুধু `com.whatsapp`-এর উইন্ডো দেখে।
- কেবল সম্মতিসহ নির্ধারিত ব্যক্তির WhatsApp মেসেজের জন্য; ফোন আনলক অবস্থায় WhatsApp-এর প্রি-ফিলড মেসেজ, প্রাপক নাম/নম্বর ও Send বাটন মিলে গেলে ক্লিকের চেষ্টা করে। নাম/নম্বর না মিললে ক্লিক করবে না।
- ক্লিক করা মানেই মেসেজ WhatsApp সার্ভারে **পৌঁছেছে**—এমন নয়। WhatsApp/HyperOS সংস্করণ, ভাষা, ব্যাকগ্রাউন্ড activity launch restrictions এবং Accessibility পরিবর্তনে অটোমেশন ব্যর্থ হতে পারে।
- লক অবস্থায় নির্ধারিত সময় এলে নোটিফিকেশন; ব্যবহারকারী PIN/বায়োমেট্রিক দিয়ে আনলক করলে কাজ এগোতে পারে, পরে আবার লক করার চেষ্টা করে।
- Android background launch বা Xiaomi battery saver কিছু কাজ বাধা দিতে পারে। ৩ সেকেন্ড আগের নোটিফিকেশন/ওভারলে **সুনির্দিষ্টভাবে গ্যারান্টিযুক্ত নয়**।
- অন্যান্য অ্যাপে ফিরে যাওয়ার জন্য `GLOBAL_ACTION_BACK` ব্যবহার করে; আগের অ্যাপে ফেরত যাওয়া সব অবস্থায় নিশ্চিত নয়।
- WhatsApp Business Cloud API বা WhatsApp-এর নিজস্ব আনুষ্ঠানিক Personal Auto-Send API ব্যবহার করা হয়নি।

## APK বানানোর জন্য
Repository-র মূল ফোল্ডারে `WA-SmartFlow-Ultra-AutoAssist-Android.zip` আপলোড করো। একটি আলাদা ফাইল `.github/workflows/build-apk.yml` বানিয়ে দেওয়া workflow-এর লেখা পেস্ট করো। এরপর GitHub **Actions → Build WA SmartFlow Ultra AutoAssist APK → Run workflow**। সফল হলে `WA-SmartFlow-Ultra-AutoAssist-APK` artifact নামিয়ে ZIP Extract করলে `app-debug.apk` পাবে।

### ফোনে চালু করার ধাপ
1. APK ইনস্টল ও অ্যাপ খুলো।
2. Control Center → `নোটিফিকেশন ও সময়ের অনুমতি` চাপো।
3. Control Center → Smart AutoAssist → `চালু` চাপো।
4. `Accessibility অনুমতি` থেকে `SmartFlow WhatsApp Assist` চালু করো। APK sideload করলে Xiaomi/Android-এর `Allow restricted settings` দরকার হতে পারে।
5. Xiaomi Settings-এ প্রয়োজন অনুযায়ী অ্যাপের ব্যাটারি অপ্টিমাইজেশন কমাও; নোটিফিকেশন ও লক স্ক্রিন নোটিফিকেশন অনুমতি দাও।
6. নিজের সম্মতিপ্রাপ্ত একটি টেস্ট নম্বর দিয়ে প্রথমে **ফোন আনলক অবস্থায়** পরীক্ষা করো। কন্টাক্টের নাম WhatsApp-এর চ্যাটের নামের সঙ্গে মিলিয়ে দাও।
7. টেস্ট সফল হলে অন্য অ্যাপ খোলা এবং লক থাকা অবস্থার ফ্লো আলাদাভাবে পরীক্ষা করো। প্রথম পরীক্ষায় গুরুত্বপূর্ণ/জরুরি বার্তা ব্যবহার কোরো না।

**ডেভেলপার নোট:** GitHub-এ debug build হয়; সোর্সের সব Android behavior বাস্তব Xiaomi ডিভাইসে পরীক্ষা করা হয়নি। Android Studio/SDK এই পরিবেশে নেই। `SCHEDULE_EXACT_ALARM` grant না থাকলে রিমাইন্ডারে বিলম্ব হতে পারে। বিশেষ পরিস্থিতিতে UI helper শুধু নোটিফিকেশন দেখাবে এবং মানুষকে Send চাপতে হবে।
