package com.smartflow.ultra;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityManager;
import org.json.JSONObject;
import java.util.List;

/** Device-local explicit opt-in; PIN is separately encrypted in PinVault. */
final class AutoAssistState {
    private static final String PREFS = "smartflow_autoassist_v1";
    private static final String ENABLED = "enabled";
    private static final long MAX_AGE = 120000;
    private AutoAssistState() {}

    static SharedPreferences prefs(Context c) {return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    static boolean isEnabled(Context c) {return prefs(c).getBoolean(ENABLED,false);}
    static void setEnabled(Context c,boolean value) {
        prefs(c).edit().putBoolean(ENABLED,value).apply();
        if (!value) clear(c);
    }
    static boolean accessibilityEnabled(Context c) {
        AccessibilityManager mgr=(AccessibilityManager)c.getSystemService(Context.ACCESSIBILITY_SERVICE);
        if(mgr==null)return false;
        List<AccessibilityServiceInfo> list=mgr.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for(AccessibilityServiceInfo i:list) {
            if(i.getResolveInfo()!=null && i.getResolveInfo().serviceInfo!=null &&
               c.getPackageName().equals(i.getResolveInfo().serviceInfo.packageName) &&
               "com.smartflow.ultra.WhatsAppAssistService".equals(i.getResolveInfo().serviceInfo.name)) return true;
        }
        return false;
    }
    static boolean overlayEnabled(Context c) {return android.os.Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(c);}
    static boolean locked(Context c) {
        KeyguardManager km=(KeyguardManager)c.getSystemService(Context.KEYGUARD_SERVICE);
        return km!=null && km.isDeviceLocked();
    }
    static synchronized boolean queue(Context c,JSONObject item,boolean wasLocked,String previousPackage) {
        if(!isEnabled(c)||item==null||!item.optBoolean("consent",false))return false;
        String id=item.optString("id","");
        String phone=item.optString("phone","").replaceAll("[^0-9]","");
        if(phone.matches("01[0-9]{9}"))phone="88"+phone;
        if(phone.matches("1[0-9]{9}"))phone="880"+phone;
        String msg=item.optString("text","").replace("{{নাম}}",item.optString("name",""))
            .replace("{{তারিখ}}",item.optString("date",""));
        if(id.isEmpty()||!phone.matches("[0-9]{8,15}")||msg.trim().isEmpty())return false;
        SharedPreferences pr=prefs(c);
        String existing=pr.getString("id","");
        long age=System.currentTimeMillis()-pr.getLong("timestamp",0);
        if(id.equals(existing)&&age>=0&&age<MAX_AGE)
            return !"clicked".equals(pr.getString("phase",""));
        // Never replace a pending message with another one; prevents accidental duplicate/misdirected clicks.
        if(!existing.isEmpty()&&age>=0&&age<MAX_AGE&& !"done".equals(pr.getString("phase","")))return false;
        return pr.edit().putString("id",id).putString("phone",phone)
           .putString("name",item.optString("name",""))
           .putString("text",msg).putBoolean("was_locked",wasLocked)
           .putString("previous_package",previousPackage==null?"":previousPackage)
           .putString("phase","queued").putLong("timestamp",System.currentTimeMillis())
           .putLong("opened",0).commit();
    }
    static boolean valid(Context c) {
        SharedPreferences pr=prefs(c);
        long age=System.currentTimeMillis()-pr.getLong("timestamp",0);
        return isEnabled(c)&&!pr.getString("id","").isEmpty()&&age>=0&&age<MAX_AGE;
    }
    static String get(Context c,String field){return prefs(c).getString(field,"");}
    static long getLong(Context c,String field){return prefs(c).getLong(field,0);}
    static boolean wasLocked(Context c){return prefs(c).getBoolean("was_locked",false);}
    static String url(Context c){return "https://wa.me/"+get(c,"phone")+"?text="+Uri.encode(get(c,"text"));}
    static synchronized void opened(Context c){prefs(c).edit().putString("phase","opened").putLong("opened",System.currentTimeMillis()).commit();}
    static synchronized void clicked(Context c){
        prefs(c).edit().putString("last_attempt_id",get(c,"id"))
            .putLong("last_attempt_at",System.currentTimeMillis())
            .putString("phase","clicked").commit();
    }
    static synchronized void clear(Context c){prefs(c).edit().remove("id").remove("phone").remove("name").remove("text")
          .remove("was_locked").remove("previous_package").remove("phase").remove("timestamp").remove("opened").apply();}
}
