package com.smartflow.ultra;

import android.accessibilityservice.AccessibilityService;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Locale;

/** Opt-in UI assistant. Only looks at WhatsApp's accessibility tree for a pending schedule.
 *  This is not a WhatsApp API and is not guaranteed to work on WhatsApp/HyperOS updates. */
public class WhatsAppAssistService extends AccessibilityService {
    private static volatile WhatsAppAssistService active;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private BroadcastReceiver unlockReceiver;
    private boolean trying;
    private long lastScan;
    private WindowManager overlayManager;
    private TextView overlayView;
    private Runnable countdownTick;
    private String countdownId;
    private long countdownDue;
    private String lastForegroundPackage="";
    private AutoPinUnlock pinUnlock;

    static boolean active() {return active!=null;}
    static void previewSoon(String id,long dueMillis) {
        WhatsAppAssistService service=active;
        if(service!=null) service.handler.post(()->service.showCountdown(id,dueMillis));
    }
    static String previousAppPackage() {
        WhatsAppAssistService service=active;
        return service==null ? "" : service.capturePreviousAppPackage();
    }
    static void tryPending() {
        WhatsAppAssistService service=active;
        if(service!=null)service.handler.post(service::startIfReady);
    }
    @Override protected void onServiceConnected() {
        super.onServiceConnected(); active=this;pinUnlock=new AutoPinUnlock(this,handler);
        unlockReceiver=new BroadcastReceiver() {
            @Override public void onReceive(Context context,Intent intent){handler.postDelayed(WhatsAppAssistService.this::startIfReady,650);}
        };
        IntentFilter f=new IntentFilter(Intent.ACTION_USER_PRESENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(unlockReceiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(unlockReceiver,f);
        handler.post(this::startIfReady);
    }
    @Override public void onDestroy() {
        if(unlockReceiver!=null)try{unregisterReceiver(unlockReceiver);}catch(Exception ignored){}
        removeCountdown();
        if(pinUnlock!=null)pinUnlock.stop();
        if(active==this)active=null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
    @Override public void onInterrupt() { }

    /** Show only the number of seconds remaining; never a notification or personal message. */
    private void showCountdown(String id,long dueTimeMillis) {
        if(!AutoAssistState.isEnabled(this)||id==null||dueTimeMillis<=0)return;
        PowerManager power=(PowerManager)getSystemService(Context.POWER_SERVICE);
        // Locked and unlocked screens are treated alike *when the display is actually on*.
        // OEM keyguards may nevertheless cover accessibility overlays.
        if(power==null||!power.isInteractive())return;
        long remaining=dueTimeMillis-System.currentTimeMillis();
        if(remaining<=0||remaining>3800)return; // Skip late/delayed/already-expired previews.
        if(id.equals(countdownId)&&overlayView!=null)return;
        removeCountdown();
        try {
            overlayManager=(WindowManager)getSystemService(WINDOW_SERVICE);
            if(overlayManager==null)return;
            TextView text=new TextView(this);
            text.setTextSize(26);text.setTextColor(Color.WHITE);
            text.setGravity(Gravity.CENTER);
            text.setPadding(dp(20),dp(9),dp(20),dp(9));
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(Color.rgb(28,35,61));bg.setCornerRadius(dp(26));
            bg.setStroke(dp(1),Color.rgb(98,219,200));
            text.setBackground(bg);text.setElevation(dp(6));
            WindowManager.LayoutParams params=new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            params.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;
            params.y=dp(70);
            overlayManager.addView(text,params);
            overlayView=text;
            countdownId=id;
            countdownDue=dueTimeMillis;
            countdownTick=new Runnable() {
                int prior=-1;
                @Override public void run() {
                    if(overlayView==null)return;
                    PowerManager p=(PowerManager)getSystemService(Context.POWER_SERVICE);
                    long left=countdownDue-System.currentTimeMillis();
                    if(p==null||!p.isInteractive()||left<=0){removeCountdown();return;}
                    int sec=(int)Math.min(3,(left+999)/1000);
                    if(sec!=prior){
                        // Bengali numerals, no recipient name/phone/message on lock screen.
                        overlayView.setText("⏳ " + (sec==3?"৩":sec==2?"২":"১"));
                        prior=sec;
                    }
                    handler.postDelayed(this,130);
                }
            };
            handler.post(countdownTick);
        }catch(Exception ignored){removeCountdown();}
    }
    private int dp(int px){return (int)(px*getResources().getDisplayMetrics().density+0.5f);}
    private void removeCountdown() {
        if(countdownTick!=null)handler.removeCallbacks(countdownTick);
        countdownTick=null;countdownId=null;countdownDue=0;
        if(overlayManager!=null&&overlayView!=null)
            try{overlayManager.removeView(overlayView);}catch(Exception ignored){}
        overlayView=null;
    }

    /** Names only; never read message content from unrelated foreground apps. */
    private boolean restorable(String pkg) {
        return pkg!=null&&!pkg.isEmpty() && !pkg.equals(getPackageName()) &&
            !pkg.equals("com.whatsapp") && !pkg.startsWith("com.android.systemui") &&
            !pkg.startsWith("com.miui.systemui") &&
            !pkg.startsWith("com.google.android.inputmethod");
    }
    private String capturePreviousAppPackage() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null&&root.getPackageName()!=null) {
            String current=root.getPackageName().toString();
            if(restorable(current))return current;
        }
        return lastForegroundPackage;
    }
    private boolean isHome(String pkg) {
        return pkg!=null&&(pkg.equals("com.miui.home")||pkg.startsWith("com.android.launcher")||
             pkg.equals("com.google.android.apps.nexuslauncher"));
    }
    private boolean currentlyAt(String pkg) {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        return root!=null&&root.getPackageName()!=null&&pkg.equals(root.getPackageName().toString());
    }
    /** If initially locked: Home, then Lock. Otherwise restore the recorded app if possible. */
    private void finishAndReturn(boolean wasLocked,String previousApp) {
        handler.postDelayed(()->{
            if(wasLocked) {
                performGlobalAction(GLOBAL_ACTION_HOME);
                handler.postDelayed(()->{
                    if(Build.VERSION.SDK_INT>=28)performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                    AutoAssistState.clear(this);
                },650);
                return;
            }
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(()->{
                if(isHome(previousApp))performGlobalAction(GLOBAL_ACTION_HOME);
                else if(restorable(previousApp)&&!currentlyAt(previousApp)) {
                    try {
                        Intent original=getPackageManager().getLaunchIntentForPackage(previousApp);
                        if(original!=null) {
                            original.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(original);
                        }
                    }catch(Exception ignored){}
                }
                AutoAssistState.clear(this);
            },750);
        },1600);
    }
    private void startIfReady() {
        removeCountdown();
        if(!AutoAssistState.valid(this))return;
        if(!"queued".equals(AutoAssistState.get(this,"phase")))return;
        if(AutoAssistState.locked(this)) {
            if(pinUnlock!=null)pinUnlock.startIfNeeded();
            return;
        }
        if(pinUnlock!=null&&pinUnlock.isRunning())pinUnlock.stop();
        PowerManager power=(PowerManager)getSystemService(Context.POWER_SERVICE);
        if(power!=null&&!power.isInteractive())return;
        // Android may restrict background activity launches. The due notification remains as fallback.
        try {
            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(AutoAssistState.url(this)));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            AutoAssistState.opened(this);
            handler.postDelayed(()->{
                if("opened".equals(AutoAssistState.get(this,"phase"))) {
                    notifyResult("WhatsApp স্ক্রিন যাচাই করা যায়নি। নোটিফিকেশন থেকে মেসেজ পাঠান।");
                    AutoAssistState.clear(this);
                }
            },18000);
        } catch(Exception ex) {
            notifyResult("WhatsApp নিজে খোলা যায়নি—নোটিফিকেশনে চাপুন।");
            AutoAssistState.clear(this);
        }
    }
    void tryReadyAfterUnlock(){handler.postDelayed(this::startIfReady,350);}
    /** Called by a visible, user-tapped activity if a background launch was blocked. */
    static void openedFromActivity(Context ctx) {AutoAssistState.opened(ctx);}

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event==null||event.getPackageName()==null)return;
        // Record only the package name of the visible app, not its contents.
        if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            String pkg=event.getPackageName().toString();
            if(restorable(pkg))lastForegroundPackage=pkg;
        }
        // PIN typing happens only in the system keyguard tree, and only for the queued job.
        if(!"com.whatsapp".contentEquals(event.getPackageName())){
            if(AutoAssistState.valid(this)&&"queued".equals(AutoAssistState.get(this,"phase"))
               &&AutoAssistState.locked(this)&&pinUnlock!=null)
                pinUnlock.startIfNeeded();
            return;
        }
        if(!AutoAssistState.valid(this)||!"opened".equals(AutoAssistState.get(this,"phase")))return;
        if(System.currentTimeMillis()-lastScan<230)return;
        lastScan=System.currentTimeMillis();
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null||root.getPackageName()==null||!"com.whatsapp".contentEquals(root.getPackageName()))return;
        String expected=AutoAssistState.get(this,"text");
        String phone=AutoAssistState.get(this,"phone");
        String name=AutoAssistState.get(this,"name");
        // Fail closed: the exact prefilled text must be visible in WhatsApp's compose box.
        if(!hasExactCompose(root,expected,0))return;
        // The actual chat must display the expected recipient name or telephone number.
        if(!hasRecipient(root,phone,name,0))return;
        AccessibilityNodeInfo send=findSendButton(root,0);
        if(send==null||!send.isEnabled()||!send.isVisibleToUser())return;
        if(!send.performAction(AccessibilityNodeInfo.ACTION_CLICK))return;
        AutoAssistState.clicked(this); // A click is NOT a delivery receipt.
        boolean relock=AutoAssistState.wasLocked(this);
        String previousApp=AutoAssistState.get(this,"previous_package");
        // A UI click is not a confirmed WhatsApp delivery receipt.
        // No success notification or repeating banner is generated.
        finishAndReturn(relock,previousApp);
    }

    private static boolean hasExactCompose(AccessibilityNodeInfo n,String text,int depth) {
        if(n==null||depth>35)return false;
        if(n.getClassName()!=null && "android.widget.EditText".contentEquals(n.getClassName()) && n.getText()!=null &&
             text.trim().equals(n.getText().toString().trim()))return true;
        for(int i=0;i<Math.min(n.getChildCount(),60);i++)if(hasExactCompose(n.getChild(i),text,depth+1))return true;
        return false;
    }
    private static boolean hasRecipient(AccessibilityNodeInfo n,String phone,String name,int depth){
        if(n==null||depth>35)return false;
        CharSequence text=n.getText();
        CharSequence cd=n.getContentDescription();
        if(matchesRecipient(text,phone,name)||matchesRecipient(cd,phone,name))return true;
        for(int i=0;i<Math.min(n.getChildCount(),60);i++)if(hasRecipient(n.getChild(i),phone,name,depth+1))return true;
        return false;
    }
    private static boolean matchesRecipient(CharSequence text,String phone,String name){
        if(text==null)return false;
        String s=text.toString().trim();
        String digits=s.replaceAll("[^0-9]","");
        // Prevent phone matches from the message body: require an exact number or exact contact name.
        if(!digits.isEmpty() && digits.equals(phone))return true;
        return name!=null&&name.trim().length()>=2&&s.equalsIgnoreCase(name.trim());
    }
    private static AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo root,int depth) {
        if(root==null||depth>35)return null;
        String viewId=root.getViewIdResourceName();
        String className=root.getClassName()==null?"":root.getClassName().toString();
        String desc=root.getContentDescription()==null?"":root.getContentDescription().toString().toLowerCase(Locale.ROOT).trim();
        if(root.isClickable() && root.isEnabled() && className.contains("ImageButton") &&
           ((viewId!=null&&(viewId.equals("com.whatsapp:id/send")||viewId.equals("com.whatsapp:id/send_button")))||
            desc.equals("send")||desc.equals("পাঠান")))return root;
        for(int i=0;i<Math.min(root.getChildCount(),60);i++) {
            AccessibilityNodeInfo found=findSendButton(root.getChild(i),depth+1);
            if(found!=null)return found;
        }
        return null;
    }
    private void notifyResult(String body) {
        ReminderScheduler.createNotificationChannel(this);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?
           new Notification.Builder(this,ReminderScheduler.CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("SmartFlow • অটোমেশন অবস্থা")
          .setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body))
          .setAutoCancel(true).setCategory(Notification.CATEGORY_STATUS);
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)try{nm.notify(9882,b.build());}catch(Exception ignored){}
    }
}
